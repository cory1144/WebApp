var path = require('path');
var express = require('express');
var bodyParser = require('body-parser');
var session = require ('express-session');
var flash = require('connect-flash');
var morgan = require('morgan');
var csurf = require('csurf');

var config = require('./config');
var twilioNotifications = require('./middleware/twilioNotifications');

var app = express();
 if(process.env.NODE_ENV !++ 'test'){
 	app,use(morgan('combined'));
 }

app.use(express.static(path.join(__dirname, 'public')));

app.use(bodyParser.urlencoded({
	extended: true
}));

app.use(session({
	secret: config.secret,
	resave: true,
	saveUninitialized: true
}));

app.use(flash());

var routes = require('./controllers/router');
var router = express.Router();

if(process.env.NODE_ENV !=='test'){
	app.use(csurf());
	app.use(function(request, response, next){
		response.locals.csrftoken = request.csrfToken();
		next();
	});
}

routes(router);
app.use(router);
app.use(function(request, response, next){
	reponse.status(404);
	reponse.sendFile(path.join(__dirname, 'public', '404.html'));
});

app.use(twilioNotifications.notifyOnError);

app.use(function(err, request, response, next){
	console.error('An application error has occured:');
	console.error(err.stack);
	response.status(500);
	response.sendFile(path.join(__dirname, 'public', '500.html'));
});

module.exports = app;