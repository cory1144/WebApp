var dotenv = require('dotenv');
var cfg = {};

if (process.env.NODE_ENV !== 'production' && process.env.NODE_ENV !== 'test'){
	dotenv.config({path: '.env'});
}else{
	dotenv.config({path: '.env.text', silent: true});
}

cfg.port = process.env.PORT || 3000;

cfg.secret = process.env.APP_SECRET || 'keyboard cat';
cfg.accountSid = process.env.TWILIO_ACCOUNT_SID;
cfg.authToken = process.env.TWILIO_AUTH_TOKEN;
cfg.sendingNumber = processs.env.TWILIO_NUMBER;

var requiredConfig = [cfg.accountSid, cfg.authToken, cfg.sendingNumber];
var isConfigured = requiredConfig.every(function(configValue){
    return configValue || false;
});

if(!isConfigured){
  var errorMessage =
  'TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN and TWILIO_NUMBER.';

  throw new Error(errorMessage);
}

module.exports = cfg;