var daysOfTheWeek = [
   "Sunday",
  "Monday",
   "Tuesday",
   "Wednesday",
  "Thursday",
  "Friday",
  "Saturday"
];

var currentDay = new Date();

setInterval(
  function(){
if(currentDay.getDay()===5){
  alert("TGIF");
}
else if(currentDay.getDay()===6){
  alert("It's the weekend, so take it easy");
}
else if(currentDay.getDay()===0){
  alert("Sundays are cool, but" + daysOfTheWeek[1] + "is just around the corner");
}
else
{
alert("You made it to " + daysOfTheWeek[currentDay.getDay()] + "\n" + "You have " + (5-currentDay.getDay()) + " days left till the end of the week!");
}
},1000*60*60*24);

setInterval(
  function (){
    var date = new Date();
    alert(daysOfTheWeek[date.getDay()]);
  },1000*60*60*24);
  
  
